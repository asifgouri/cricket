import { Scorecard } from './scorecard';

export interface MatchScoreCard{
    team1: Scorecard
    team2: Scorecard
}